/**
 * LBC ReLister - Firefox Edition v1.3.0
 *
 * Fix v1.3:
 * - Injection boutons plus fiable (observer body entier, 6 tentatives échelonnées)
 * - Tous les dialogues en popup custom (prix, confirmation, champs manquants)
 * - Champs manquants dynamiques : pas besoin de connaître les valeurs à l'avance
 * - Champs en texte libre si non reconnus, select si options connues
 */

(function () {
  "use strict";

  const VERSION = "1.3.0";

  // ─── CONFIG ────────────────────────────────────────────────────────────────

  const config = {
    selectors: {
      adContainer: 'li[data-qa-id="ad_item_container"]',
      adLink: 'a[href*="/ad/"]',
      buttonContainer: ".mt-md.gap-md.flex.flex-wrap",
      republishButton: "[data-lbc-republish-btn]",
    },
    delays: {
      buttonInjection: 300,
      notificationFade: 6000,
      notificationError: 10000,
      beforeSubmit: 1000,
      fadeOut: 300,
    },
    api: {
      adData: (id) => `https://api.leboncoin.fr/api/pintad/v1/public/manual/classified/${id}`,
      deleteAd: "https://api.leboncoin.fr/api/pintad/v1/public/manual/delete/ads",
      createAd: "https://api.leboncoin.fr/api/adsubmit/v2/classifieds?with_variation=true",
      pricing: "https://api.leboncoin.fr/api/options/v4/pricing/classifieds",
      submit: "https://api.leboncoin.fr/api/services/v4/submit",
      // Retourne les champs et options valides pour une catégorie donnée
      categoryParams: (categoryId) => `https://api.leboncoin.fr/api/adsubmit/v2/classifieds/params/${categoryId}`,
    },
    headers: {
      accept: "*/*",
      acceptLanguage: "fr-FR,fr;q=0.9",
      contentType: "application/json",
      origin: "https://www.leboncoin.fr",
      deleteApiKey: "ba0c2dad52b3ec",
    },
    referers: {
      deposit: "https://www.leboncoin.fr/deposer-une-annonce",
      options: "https://www.leboncoin.fr/deposer-une-annonce/options",
      deletion: "https://www.leboncoin.fr/compte/mes-annonces/suppression",
    },
    readOnlyFields: ["list_id", "ad_id", "first_publication_date", "index_date", "status", "url", "price"],
  };

  // ─── UTILS ─────────────────────────────────────────────────────────────────

  const log = (level, msg, data) => {
    const fn = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
    fn(`[LBC-ReLister v${VERSION}] ${msg}`, data ?? "");
  };

  const sanitize = (str) => {
    const el = document.createElement("div");
    el.textContent = String(str ?? "");
    return el.innerHTML;
  };

  const getCookie = (name) => {
    const m = document.cookie.match(new RegExp(`${name}=([^;]+)`));
    return m ? m[1] : null;
  };

  const getAuthToken = () => {
    const key = "luat";
    const token = getCookie(key) || localStorage.getItem(key);
    if (!token) throw new Error("Token d'authentification non trouvé. Reconnectez-vous à Leboncoin.");
    return token;
  };

  const makeHeaders = (token, experiment, referer) => ({
    accept: config.headers.accept,
    "accept-language": config.headers.acceptLanguage,
    authorization: `Bearer ${token}`,
    "content-type": config.headers.contentType,
    origin: config.headers.origin,
    referer,
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "x-lbc-experiment": experiment,
  });

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const getExperiment = () =>
    btoa(JSON.stringify({ version: 1, rollout_visitor_id: getCookie("cnfdVisitorId") || "" }));

  // ─── API ERROR ──────────────────────────────────────────────────────────────

  class ApiError extends Error {
    constructor(action, status, body) {
      super(`${action} a échoué (HTTP ${status})`);
      this.action = action;
      this.status = status;
      this.rawBody = body;
      this.missingFields = [];
      try {
        const json = JSON.parse(body);
        if (Array.isArray(json.details)) {
          this.missingFields = json.details.map((d) => ({ field: d.field, message: d.message }));
        }
      } catch (_) {}
    }
    hasMissingFields() {
      return this.status === 400 && this.missingFields.length > 0;
    }
  }

  const checkResponse = async (resp, action) => {
    if (!resp.ok) {
      const body = await resp.text();
      throw new ApiError(action, resp.status, body);
    }
    return resp;
  };

  // ─── LOGO ───────────────────────────────────────────────────────────────────

  const LOGO_B64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAKsElEQVR4AZSZy7JfRRXGV//FUEImhiewyhtaVp2ISVC8R0mVzBjwAGFgecOUAspFEYVowcCIThjAQKscMGQEA8aGMDBliVq+gVowIPfknL38fmt19+69c06Apr9et68va+3e+5wTNrZq27+++/h08tgr2yfvfmvn5Dd95+lvBLafOuqBX33dt8Evv+bbwrUnv+rXnvyKX/sF+LJffeKLwpf86s8lwc/u8qvClcfv8iuPf8GvPPb5wOVH7/TLjx7xy48c8SuPHPbLPz0UuPSTz3ng4Tv8knDxoc/6xQcPvnXhwYOvXPrRweOr41pPwJ+5Z8t/c+z1jZUXrPixYn6gDGx0MLgWqlerGP9VQ6IIdK2nCBrw0DPm5rgq0NOfDvRSCmc55ht/4eKPt16/+tDWVkYtE/BnvrXl0/Zr7n5YMMCqPmlxX0JBA3AAOijiIfEBdDDJjz0i1q5+dHgtzjroaz8cfIodvrYzvXb+xNYWSWwK47TzvIIHULGplo5tlCltWzY51Ql3P5XTGmETC0UDemGQTk892HX+rENLC+asYTXAEQ6UMj2Pb3NNd56sBCWpY/skqVCtUPOHs/kmOG5TcFM3dDJonConZH+S4lbd8O+C9gSc9RSHZ74j4YLmV7/ihy+c+MzxzcbLfTququECWkJZWlYr7XEkho1swB7R/EjtbEgwc7yrS78Ft40WrYSvhK4bLInu7vdtlNchgT0EaTVrBY13wEZbevgl1/61veBpw4Wt+eqaoiSkENPj1Mly/7DlLwJ6h56eJukbkzxNOMQ7cKBoHRnaxiJTUyNDIDU6ekM4NMQ0ybGvORHLDfra+HjP4KIHqlFFuFgfG6CPC+ATDmy83ylR1hl3m7tH1kiQOtVo8M4l1lC5UbmmI1WuXfk5z/qZxK3v2+xbnnPTUlU2od54KFGEsgsJH8iQV57LBBKti0T1BzO4aXvXRUsdRR8HBIDnDIFiegLKWoRWQVNlwNrGZ60y4tuK1/jICKvqUNDh4gdNRwJ8AB3ujiZhj8BPHB8SoLvOwzuQmdqykS1Yeqs1lyDmjrzURZCirgnSNRYxi+S7da5E8uqYInKoaiyBDvIJKGuyAi7dlZl3qXvYdR1G+szT05PtjW+NmzxXLH4OSLq+5VPInNPWQFqbH7KtscOLotDAVxqsOWPKXyUiJQVTmmplvZEl6I6q4APVjDn1Y1NdHhIOMDGQDbZqa38Rf0VRQhbe8R3amKoCUmhTKWSID6ADdDBWEf/mI3fYBx9+2fY9/Rfb99Rpu/nkabvp3segCnutl1Xm288aIzRJB6XqlaPz4Bs5uPABrpzRigYgEV1bh+xDdTBh5EVJGmkIUCXMmIbSOCGrQ0J9sUSENaz9SztWFcvqVyjuXsu6Zd6kyEpZUSWsEb2jcmKpYejxOje+SJWrmGm/fJL4AOsitYbiy2oTa4Cz1CmoZs29SAUSi44PpNOjaml7uvYY4QCLGTOXjdOfPnSeWlq2aMSaA85o93fAlDlo2aMv7mhUMbPnfZ95bemV3G09na7Nm6Xmidvs2Hdlu56Yy0fMXcf3WCjeFQqhFa7vohlFKxqKqcVgskxNC2jMPurpuW6sc/GjAnRwI333mK4REwOFd0AOZeRDlmQad1Slbn4fOOgKRQXktuuanHAAa1n9fcZjj9zPpNuK54OdenJHnTmg+W78k7gX162Y1epbbVOV70G4xdyxorZuNYjgnhPWNM1zAWtGciz8e/wkzrtOlmRLtdFB2sR5AM6QMDWZGrOrmnCZ4/oJh+Sp4tt1veEdY2ry5n342wBfWwcJhncgd+evMDLMU7SxxpopSZVGXjBGhzh0XDo/alQsBw9BLAIa0IFUdRcsOKpOyPSkb+aZfpUgXUHdqBB/hbnup8vhXWp66NxJQGVmmFoRWic57/Mbv8pFpVmj+jsfH9AVla9VPdfDP4NYfwJFeX6gnaDKElKHD8mQnhyxzXhitmrMgANaCB00e5bFSDhtD72ksRjxAZyuIXXnK6SMdCldFW6/i8vUk5M/KiC2pK9A9gC/GENnHtORE0oAHmAOQAdNR7KvtpGqI0ohvoaCw3pm+RUSnxMUDUAMaaZqmFoG8TfIeYNe6jwohWFXEAE2sE1tfhoy1OEAqb1j817B7V+hzHS+j2SaPiq5N6haX7kqYmt6Vj/W0L2XQ3VRZFFZ9gP4UwZP/Ji34KqQ3RZXG8u0+g541IHM6hkkXMg++tGBTpPBcaxTEIt3IycEs1UuDA1UcQjrWOG87jzBYXJExInuSoA0tGPLOCogn7rUCKRUVaSoUy38WiFJUmqPXUz/bqP0xGdNTZCRc7ClVRdryJIIh/jI4GjdJvGBsCfTWhqGuP5hS87Me5HbujKw3g/IBbQ56PVxy+XDXjqQPM0BD1hzGC356ce2iGLHb6NkZ/oKIb1LqjNASboyNzD8bmP6O9gWze2mO++1W079PXDr7960wHNv2i3P/cP2//6fwr9s/x8EcW6+54SWHPbR+uzjOocClj+XWlx3v/9tje66QjpY25+M0Jts+mw7LiP9vZ8QEXvfjT1Am5i69kulubV14dDWmp6A1Jo1P4mt6kjgC9vkatVouuav+rynDtBjs1czu1erDWuKr/3kUFdEphTR0Zdofl1LWKbMEvYujWOARks912i+sGJonrXMWXh5XmGt+PiIwQFUGh/6iOHnQN6prDhJZ8aZqWK6aq57OQmuKgFi2/8+bRefOGoXfvjpwPkHPmUXhPMP3G7nf3C7nfv+J4VP2LnvfTzx3Y/ZOeGd73zU3lH88suntIz20vpS1KUPe3jV598SlCn7i++S8RXKzOZxzLxlyyc4GenZjUMEzhhDx0csoP2R+AA6SL0GcVS0fTNenQhR8W34PZtMlLo62Sdk8Bgk0oYD4MuprqeiCkjZhacdaiyFdlOHq9UkNCrAF0bGMH+cVzm10kueFtPPDc6jd0CTaiejVEVIZc93oyhSKgeBDtB1ohQxupgozhB653XFln4z2UWw2kqVJl8RzHKw+tso1ah3bZkpVQZUo0n0NVqsSeKpsx6V2g1zLLkeZ2h6+/9iSjz8rAkm1adxJj6p/nYxGqOjBLDG32fCbmkHYx6INYs73/RRwgHNFzoXvDmqxA+queuOnBJOsfK2vkL2husJUA1dN3WyrKj3jBgcd7JnOvGsQoshAUsVhgqXHAEHhE/LoYOwBy4+0PzooNkppzc2+oPgpZYtkqIUFKCzdl12r274y67V0fNVEUSuvUgCiUXHFx+E6mVtfGF2xWKPbsa+6TNaKS9tPvTsX180n87UjMxVZY9KRHlkU23NDJ+OFzJ93rnY7Ylo5QWHGNB63Z9cebX+qOc++uNc/tQ95lROqVI+neTMbX/8z4vxFbppU74tR30XdAD1nrX0sTOBajUf+pKrjRXEB6RGL6olBw6jDcXkNV5EbW9zyyVmW6wii9uRRN39HdeZLefue/bsWZ82R5XYGaUujraSQfZrewq/VpMklmLS3wDaVQZzAsP7kzzi4zztUTmsCQfEXE46rjU8aa1wZrMzHf3wn/93VnomgLL/1Nmzt/72b0ek36+tXpWsT6Qof+swGhsgA64YzyEM6RYYBqMVDSD9FiJsWzZ84/Jh62ujdF+1Uu6/7U//PdIOz8z/AwAA//+RdEHCAAAABklEQVQDAFfZr99dEz2pAAAAAElFTkSuQmCC";

  // ─── DESIGN SYSTEM ──────────────────────────────────────────────────────────

  const C = {
    bg: "#1a1c1e",
    surface: "#25282c",
    border: "#35393f",
    text: "#e8eaed",
    muted: "#9aa0a8",
    accent: "linear-gradient(135deg,#ff8a4a 0%,#ec5a13 100%)",
    accentSolid: "#f07030",
    danger: "#ef4444",
    success: "#10b981",
    inputBg: "#2c3035",
  };

  const ensureStyles = (() => {
    let done = false;
    return () => {
      if (done) return;
      done = true;
      const s = document.createElement("style");
      s.id = "lbc-relister-styles";
      s.textContent = `
        @keyframes lbc-fade-in{from{opacity:0}to{opacity:1}}
        @keyframes lbc-slide-up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
        .lbc-input:focus{border-color:${C.accentSolid}!important;outline:none;}
        .lbc-btn-primary:hover{transform:translateY(-1px)!important;box-shadow:0 6px 18px rgba(240,112,48,.4)!important;}
        .lbc-btn-secondary:hover{border-color:${C.text}!important;color:${C.text}!important;}
        .lbc-input::-webkit-outer-spin-button,.lbc-input::-webkit-inner-spin-button{-webkit-appearance:none;}
      `;
      document.head.appendChild(s);
    };
  })();

  // ── styles helpers ──
  const S = {
    overlay: `position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:1000000;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);animation:lbc-fade-in .15s ease;`,
    modal: `background:${C.bg};border:1px solid ${C.border};border-radius:16px;padding:28px;width:440px;max-width:94vw;box-shadow:0 24px 64px rgba(0,0,0,0.6);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;color:${C.text};animation:lbc-slide-up .2s ease;`,
    label: `display:block;font-size:11px;font-weight:600;color:${C.muted};text-transform:uppercase;letter-spacing:.05em;margin-bottom:7px;`,
    input: `width:100%;padding:10px 13px;border-radius:8px;border:1.5px solid ${C.border};background:${C.inputBg};color:${C.text};font-size:14px;box-sizing:border-box;transition:border-color .15s;`,
    select: `width:100%;padding:10px 13px;border-radius:8px;border:1.5px solid ${C.border};background:${C.inputBg};color:${C.text};font-size:14px;box-sizing:border-box;cursor:pointer;`,
    btnPrimary: `flex:1;padding:11px 16px;border-radius:9px;border:none;background:${C.accent};color:white;font-size:14px;font-weight:700;cursor:pointer;transition:transform .12s,box-shadow .12s;box-shadow:0 2px 12px rgba(240,112,48,.3);`,
    btnSecondary: `padding:11px 16px;border-radius:9px;border:1.5px solid ${C.border};background:transparent;color:${C.muted};font-size:14px;font-weight:600;cursor:pointer;transition:border-color .12s,color .12s;`,
    btnRow: `display:flex;gap:10px;margin-top:22px;`,
    hint: `font-size:11px;color:${C.muted};margin-top:5px;line-height:1.4;`,
    errMsg: `font-size:11px;color:${C.danger};margin-top:5px;display:none;`,
    infoBox: `background:${C.surface};border:1px solid ${C.border};border-radius:10px;padding:14px 16px;margin-bottom:18px;`,
    infoRow: `display:flex;justify-content:space-between;align-items:baseline;padding:5px 0;`,
    infoLabel: `font-size:12px;color:${C.muted};flex-shrink:0;`,
    infoVal: `font-size:13px;font-weight:600;color:${C.text};text-align:right;word-break:break-word;margin-left:12px;`,
    warnBox: `background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);border-radius:10px;padding:12px 14px;font-size:12px;color:#fca5a5;line-height:1.5;`,
    fieldGap: `margin-bottom:18px;`,
  };

  const header = (title, sub) => `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:22px;">
      <img src="${LOGO_B64}" width="32" height="32" style="border-radius:8px;flex-shrink:0;" />
      <div>
        <div style="font-size:17px;font-weight:700;">${title}</div>
        <div style="font-size:12px;color:${C.muted};margin-top:2px;">${sub}</div>
      </div>
    </div>
  `;

  const makeOverlay = () => {
    ensureStyles();
    const ov = document.createElement("div");
    ov.style.cssText = S.overlay;
    const mo = document.createElement("div");
    mo.style.cssText = S.modal;
    ov.appendChild(mo);
    document.body.appendChild(ov);
    return { ov, mo };
  };

  // ─── MODAL PRIX ─────────────────────────────────────────────────────────────

  // Popup unique : infos annonce + prix + republier directement
  const showPriceModal = (ad) => new Promise((resolve) => {
    const { ov, mo } = makeOverlay();
    mo.innerHTML = header("Republier cette annonce", "Modifiez le prix si besoin puis lancez") + `
      <div style="${S.infoBox}">
        <div style="${S.infoRow}"><span style="${S.infoLabel}">Titre</span><span style="${S.infoVal}">${sanitize(ad.subject)}</span></div>
        <div style="${S.infoRow}"><span style="${S.infoLabel}">Catégorie</span><span style="${S.infoVal}">${sanitize(ad.category_name)}</span></div>
      </div>
      <label style="${S.label}">Prix (€)</label>
      <div style="position:relative;margin-bottom:6px;">
        <input id="lbc-p-input" class="lbc-input" type="number" min="1" step="0.01" value="${sanitize(String(ad.price))}"
          style="${S.input};padding-right:32px;" />
        <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:${C.muted};font-size:14px;pointer-events:none;">€</span>
      </div>
      <div id="lbc-p-err" style="${S.errMsg}">Prix invalide — entrez un nombre positif.</div>
      <div style="${S.warnBox};margin-top:14px;">⚠️ L'ancienne annonce sera <strong>supprimée définitivement</strong> après la republication.</div>
      <div style="${S.btnRow}">
        <button id="lbc-p-cancel" class="lbc-btn-secondary" style="${S.btnSecondary}">Annuler</button>
        <button id="lbc-p-ok" class="lbc-btn-primary" style="${S.btnPrimary}">✨ Republier maintenant</button>
      </div>
    `;
    const inp = mo.querySelector("#lbc-p-input");
    setTimeout(() => { inp.focus(); inp.select(); }, 40);
    mo.querySelector("#lbc-p-cancel").addEventListener("click", () => { ov.remove(); resolve(null); });
    mo.querySelector("#lbc-p-ok").addEventListener("click", () => {
      const v = parseFloat(inp.value);
      if (isNaN(v) || v <= 0) {
        mo.querySelector("#lbc-p-err").style.display = "block";
        inp.style.borderColor = C.danger;
        return;
      }
      ov.remove(); resolve(v);
    });
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") mo.querySelector("#lbc-p-ok").click();
      if (e.key === "Escape") mo.querySelector("#lbc-p-cancel").click();
    });
  });

  // ─── MODAL CHAMPS MANQUANTS ──────────────────────────────────────────────────

  // ─── CATÉGORIE PARAMS (fetch dynamique depuis l'API leboncoin) ──────────────

  /**
   * Cache en mémoire pour éviter de re-fetcher la même catégorie.
   * clé = categoryId, valeur = Map<fieldKey, [{v, l}]>
   */
  const _categoryParamsCache = new Map();

  /**
   * Interroge l'API leboncoin pour récupérer les champs et options valides
   * d'une catégorie. Retourne une Map : fieldKey → [{v: valeur, l: label}]
   * ou un objet vide si l'API échoue (on affichera un input texte à la place).
   */
  const fetchCategoryParams = async (categoryId) => {
    if (_categoryParamsCache.has(categoryId)) return _categoryParamsCache.get(categoryId);

    const result = new Map();
    try {
      const token = getAuthToken();
      const resp = await fetch(config.api.categoryParams(categoryId), {
        method: "GET",
        headers: {
          accept: config.headers.accept,
          authorization: `Bearer ${token}`,
          "content-type": config.headers.contentType,
          origin: config.headers.origin,
          referer: config.referers.deposit,
        },
        credentials: "include",
      });

      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data = await resp.json();

      /**
       * La réponse contient un tableau "params" ou "fields", chaque entrée ayant :
       *   { key: "computer_type", label: "Type de produit", values: [{value:"1",label:"Ordinateur portable"}, ...] }
       *
       * On normalise vers notre format interne {v, l}.
       */
      const params = data.params || data.fields || data.attributes || [];
      params.forEach((param) => {
        const key = param.key || param.name;
        const label = param.label;
        const values = param.values || param.options || param.enum || [];
        if (key && values.length > 0) {
          result.set(key, {
            label: label || key,
            options: values.map((val) => ({
              v: String(val.value ?? val.key ?? val.id ?? val),
              l: String(val.label ?? val.name ?? val.value ?? val),
            })),
          });
        }
      });

      log("info", `Params catégorie ${categoryId} chargés`, { fields: result.size });
    } catch (err) {
      log("warn", `Impossible de charger les params de la catégorie ${categoryId}`, err.message);
    }

    _categoryParamsCache.set(categoryId, result);
    return result;
  };

  // Labels de fallback si l'API ne retourne pas de label
  const FIELD_LABELS_FALLBACK = {
    condition: "État de l'objet",
    computer_type: "Type de produit informatique",
    vehicle_type: "Type de véhicule",
    real_estate_type: "Type de bien immobilier",
    furnished: "Meublé",
    energy_rate: "Classe énergétique DPE",
    ges: "Émissions GES",
    rooms: "Nombre de pièces",
    square: "Surface (m²)",
    mileage: "Kilométrage",
    regdate: "Année de mise en circulation",
    fuel: "Carburant",
    gearbox: "Boîte de vitesses",
    doors: "Nombre de portes",
    seats: "Nombre de places",
    horse_power: "Puissance (CV)",
    phone_brand: "Marque du téléphone",
    phone_model: "Modèle du téléphone",
    size: "Taille / pointure",
  };

  /**
   * Affiche la modale de champs manquants.
   * categoryId est optionnel — si fourni, on tente de charger les options depuis l'API.
   */
  const showMissingFieldsModal = async (fields, adSubject, categoryId) => {
    // Tente de récupérer les params de la catégorie
    const categoryParams = categoryId ? await fetchCategoryParams(categoryId) : new Map();

    return new Promise((resolve) => {
      const { ov, mo } = makeOverlay();

      // Affiche un spinner pendant le chargement (déjà résolu ici mais UX cohérente)
      const fieldsHtml = fields.map(({ field, message }) => {
        const fieldId = sanitize(field);
        const fromApi = categoryParams.get(field);
        const label = fromApi?.label || FIELD_LABELS_FALLBACK[field] || field.replace(/_/g, " ");
        const opts = fromApi?.options;

        const inputEl = opts && opts.length > 0
          ? `<select data-field="${fieldId}" class="lbc-input" style="${S.select}">
               <option value="">— Choisir —</option>
               ${opts.map((o) => `<option value="${sanitize(o.v)}">${sanitize(o.l)}</option>`).join("")}
             </select>`
          : `<input type="text" data-field="${fieldId}" class="lbc-input"
               placeholder="${sanitize(message)}" style="${S.input}" autocomplete="off" />`;

        const sourceTag = fromApi
          ? `<span style="font-size:10px;color:${C.success};margin-left:6px;">✓ options chargées</span>`
          : "";

        return `
          <div style="${S.fieldGap}">
            <label style="${S.label}">${sanitize(label)}${sourceTag}</label>
            ${inputEl}
            <div id="lbc-fe-${fieldId}" style="${S.errMsg}">Ce champ est requis.</div>
            <div style="${S.hint}">💬 ${sanitize(message)}</div>
          </div>
        `;
      }).join("");

      mo.innerHTML = header("Champs requis manquants", `${fields.length} champ${fields.length > 1 ? "s" : ""} à renseigner pour republier`) + `
        <div style="${S.warnBox};margin-bottom:18px;">
          L'API a rejeté l'annonce <strong>${sanitize(adSubject)}</strong>.<br>
          Renseignez les champs ci-dessous pour corriger le problème.
        </div>
        <div>${fieldsHtml}</div>
        <div style="${S.btnRow}">
          <button id="lbc-f-cancel" class="lbc-btn-secondary" style="${S.btnSecondary}">Annuler</button>
          <button id="lbc-f-ok" class="lbc-btn-primary" style="${S.btnPrimary}">✨ Republier avec ces champs</button>
        </div>
      `;

      setTimeout(() => { const f = mo.querySelector(".lbc-input"); if (f) f.focus(); }, 40);

      mo.querySelector("#lbc-f-cancel").addEventListener("click", () => { ov.remove(); resolve(null); });
      mo.querySelector("#lbc-f-ok").addEventListener("click", () => {
        const result = {};
        let valid = true;
        mo.querySelectorAll("[data-field]").forEach((el) => {
          const field = el.dataset.field;
          const val = el.value.trim();
          const errEl = mo.querySelector(`#lbc-fe-${field}`);
          if (!val) {
            valid = false;
            el.style.borderColor = C.danger;
            if (errEl) errEl.style.display = "block";
          } else {
            el.style.borderColor = C.border;
            if (errEl) errEl.style.display = "none";
            result[field] = val;
          }
        });
        if (!valid) return;
        ov.remove();
        resolve(result);
      });
    });
  };

  // ─── TOASTS ──────────────────────────────────────────────────────────────────

  const toast = {
    mk({ id, border = "#6b7280", content }) {
      ensureStyles();
      const el = document.createElement("div");
      el.id = id;
      el.style.cssText = `
        position:fixed;top:20px;right:20px;
        background:${C.bg};border:1px solid ${C.border};
        padding:12px 16px;border-radius:10px;
        box-shadow:0 4px 20px rgba(0,0,0,.45);
        z-index:999999;
        font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
        font-size:13px;font-weight:500;
        border-left:3px solid ${border};
        max-width:320px;line-height:1.4;
        display:flex;align-items:flex-start;gap:10px;
        animation:lbc-fade-in .2s ease;
        color:${C.text};
      `;
      el.innerHTML = `
        <img src="${LOGO_B64}" width="20" height="20" style="flex-shrink:0;margin-top:1px;border-radius:4px;" />
        <div style="flex:1;">${content}</div>
      `;
      document.body.appendChild(el);
      return el;
    },
    remove(id) { document.getElementById(id)?.remove(); },
    removeAll() { ["lbc-loading","lbc-publishing","lbc-deleting","lbc-success","lbc-error"].forEach(id => this.remove(id)); },
    fadeOut(el, ms) {
      setTimeout(() => {
        el.style.transition = "opacity .3s";
        el.style.opacity = "0";
        setTimeout(() => el.remove(), 350);
      }, ms);
    },
    loading: (msg = "Chargement...") => toast.mk({ id: "lbc-loading", border: C.accentSolid, content: msg }),
    publishing: () => toast.mk({ id: "lbc-publishing", border: C.accentSolid, content: "Publication de la nouvelle annonce..." }),
    deleting: () => toast.mk({ id: "lbc-deleting", border: "#ec5a13", content: "Suppression de l'ancienne annonce..." }),
    success: (adId) => toast.mk({ id: "lbc-success", border: C.success,
      content: `<div style="font-weight:600;margin-bottom:4px;">✅ Republication réussie</div><div style="font-size:12px;color:${C.muted}">Annonce #${sanitize(String(adId))} créée. Rafraîchissez la page.</div>` }),
    error: (msg) => toast.mk({ id: "lbc-error", border: C.danger,
      content: `<div style="font-weight:600;margin-bottom:4px;">❌ Erreur</div><div style="font-size:12px;color:${C.muted}">${sanitize(msg)}</div>` }),
  };

  // ─── API ────────────────────────────────────────────────────────────────────

  const fetchAdData = async (listId) => {
    const token = getAuthToken();
    const resp = await fetch(config.api.adData(listId), {
      method: "GET",
      headers: { accept: config.headers.accept, authorization: `Bearer ${token}`, "content-type": config.headers.contentType },
      credentials: "include",
    });
    await checkResponse(resp, "fetchAdData");
    return resp.json();
  };

  const prepareAdData = (ad) => {
    const out = { ...ad, tracking_dd: `app:${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 10)}` };
    if (typeof out.price === "number") out.price_cents = Math.round(100 * out.price).toString();
    config.readOnlyFields.forEach((f) => delete out[f]);

    /**
     * L'API de récupération retourne les attributs sous forme de tableau :
     *   attributes: [ { key: "computer_type", value: "2" }, ... ]
     *
     * L'API de création attend ces mêmes champs à plat au niveau racine :
     *   { computer_type: "2", condition: "3", ... }
     *
     * On aplatit donc le tableau attributes vers des champs racine,
     * sans écraser un champ déjà présent (cas où l'utilisateur a déjà renseigné).
     */
    if (Array.isArray(out.attributes)) {
      out.attributes.forEach(({ key, value }) => {
        if (key && value !== undefined && value !== null && !(key in out)) {
          out[key] = String(value);
        }
      });
      // L'API de création n'attend pas le tableau attributes
      delete out.attributes;
    }

    return out;
  };

  const createAdDraft = async (adData, token, experiment) => {
    const resp = await fetch(config.api.createAd, {
      method: "POST",
      headers: makeHeaders(token, experiment, config.referers.deposit),
      credentials: "include",
      body: JSON.stringify(adData),
    });
    await checkResponse(resp, "createAdDraft");
    const json = await resp.json();
    if (!json.ad_id) throw new Error("Pas d'ad_id dans la réponse");
    return { ad_id: json.ad_id, action_id: json.action_id || 1 };
  };

  const fetchPricingId = async (adId, actionId, categoryId, token, experiment) => {
    const resp = await fetch(config.api.pricing, {
      method: "POST",
      headers: makeHeaders(token, experiment, config.referers.options),
      credentials: "include",
      body: JSON.stringify({
        user_journey: "deposit", page_name: "option",
        classifieds: [{ ad_id: adId, category: categoryId.toString(), action_id: actionId }],
        is_edit_refused: false,
      }),
    });
    await checkResponse(resp, "fetchPricingId");
    const json = await resp.json();
    if (!json.pricing_id) throw new Error("Pas de pricing_id dans la réponse");
    return json.pricing_id;
  };

  const submitAd = async (adId, actionId, adType, pricingId, token, experiment) => {
    await sleep(config.delays.beforeSubmit);
    const resp = await fetch(config.api.submit, {
      method: "POST",
      headers: makeHeaders(token, experiment, config.referers.options),
      credentials: "include",
      body: JSON.stringify({
        ads: [{ ad_type: adType, ad_id: adId, options: [], action_id: actionId, transaction_type: "new_ad" }],
        pricing_id: pricingId, user_journey: "deposit",
      }),
    });
    await checkResponse(resp, "publishAd");
  };

  const deleteOldAd = async (listId) => {
    const token = getAuthToken();
    const resp = await fetch(config.api.deleteAd, {
      method: "DELETE",
      headers: {
        accept: config.headers.accept, api_key: config.headers.deleteApiKey,
        authorization: `Bearer ${token}`, "content-type": config.headers.contentType,
        origin: config.headers.origin, referer: config.referers.deletion,
      },
      body: JSON.stringify({ list_ids: [parseInt(listId, 10)] }),
      credentials: "include",
    });
    await checkResponse(resp, "deleteAd");
  };

  /**
   * Crée l'annonce, retry jusqu'à 3x si des champs manquent (erreur 400).
   */
  const publishAd = async (adData) => {
    const token = getAuthToken();
    const experiment = getExperiment();
    let prepared = prepareAdData(adData);
    let draftResult = null;

    // Pré-charge les params de catégorie en parallèle (pour la modale si besoin)
    if (adData.category_id) fetchCategoryParams(adData.category_id).catch(() => {});

    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        draftResult = await createAdDraft(prepared, token, experiment);
        break;
      } catch (err) {
        if (err instanceof ApiError && err.hasMissingFields()) {
          // Construit la liste des champs manquants lisibles
          const fieldList = err.missingFields
            .map(({ field, message }) => `• ${message} (champ : ${field})`)
            .join("\n");
          throw new Error(
            `L'annonce a été rejetée car des champs obligatoires (*) sont manquants.\n\n` +
            `Modifiez votre annonce sur Leboncoin pour renseigner :\n${fieldList}\n\n` +
            `Puis relancez la republication.`
          );
        } else {
          throw err;
        }
      }
    }

    if (!draftResult) throw new Error("Impossible de créer le brouillon après 3 tentatives.");
    const { ad_id, action_id } = draftResult;
    const pricingId = await fetchPricingId(ad_id, action_id, prepared.category_id, token, experiment);
    await submitAd(ad_id, action_id, prepared.ad_type, pricingId, token, experiment);
    return ad_id;
  };

  // ─── REPUBLISH FLOW ─────────────────────────────────────────────────────────

  const handleRepublish = async (listId) => {
    log("info", "Republication démarrée", { listId });
    const loadingEl = toast.loading("Chargement des données...");
    try {
      const adData = await fetchAdData(listId);
      loadingEl.remove();

      const newPrice = await showPriceModal(adData);
      if (newPrice === null) return;

      toast.publishing();
      const newAdId = await publishAd({ ...adData, price: newPrice });
      toast.remove("lbc-publishing");

      toast.deleting();
      await deleteOldAd(listId);
      toast.remove("lbc-deleting");

      const successEl = toast.success(newAdId);
      toast.fadeOut(successEl, config.delays.notificationFade);
      log("info", "Republication terminée", { newAdId });
    } catch (err) {
      log("error", "Erreur", err);
      toast.removeAll();
      const errEl = toast.error(err.message);
      setTimeout(() => errEl.remove(), config.delays.notificationError);
    }
  };

  // ─── INJECTION BOUTONS ──────────────────────────────────────────────────────

  const extractListId = (href) => href?.match(/\/(\d+)$/)?.[1] ?? null;

  const createBtn = (listId) => {
    const w = document.createElement("div");
    w.className = "shrink-0 grow-0 md:basis-auto basis-[calc(50%-1rem)]";
    w.innerHTML = `
      <button
        data-lbc-republish-btn="${listId}"
        data-spark-component="button"
        type="button"
        class="u-shadow-border-transition box-border inline-flex items-center justify-center gap-md whitespace-nowrap default:px-lg text-body-1 font-bold focus-visible:u-outline min-w-sz-44 h-sz-44 rounded-lg cursor-pointer w-full"
        style="background:linear-gradient(135deg,#ff8a4a 0%,#ec5a13 100%);color:white;transition:transform .15s,box-shadow .15s;"
        onmouseover="this.style.transform='scale(1.02)';this.style.boxShadow='0 4px 16px rgba(240,112,48,.35)'"
        onmouseout="this.style.transform='scale(1)';this.style.boxShadow='none'"
        title="Republier cette annonce">✨ Republier</button>
    `;
    w.querySelector("button").addEventListener("click", () => handleRepublish(listId));
    return w;
  };

  const injectButtons = () => {
    try {
      let n = 0;
      document.querySelectorAll(config.selectors.adContainer).forEach((container) => {
        if (container.querySelector(config.selectors.republishButton)) return;
        const link = container.querySelector(config.selectors.adLink);
        if (!link) return;
        const listId = extractListId(link.getAttribute("href"));
        if (!listId) return;
        const btnBox = container.querySelector(config.selectors.buttonContainer);
        if (!btnBox) return;
        btnBox.appendChild(createBtn(listId));
        n++;
      });
      if (n) log("info", `${n} bouton(s) injecté(s)`);
    } catch (e) { log("error", "Erreur injection", e); }
  };

  // ─── OBSERVER + INIT ────────────────────────────────────────────────────────

  const debounce = (fn, ms) => {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  };

  const debouncedInject = debounce(injectButtons, config.delays.buttonInjection);

  let observer = null;

  /**
   * Observer sur document.body entier (subtree:true) pour ne rater aucun
   * chargement dynamique de leboncoin, quel que soit l'ordre de montage.
   */
  const startObserver = () => {
    observer?.disconnect();
    observer = new MutationObserver((mutations) => {
      const relevant = mutations.some((m) =>
        Array.from(m.addedNodes).some((n) =>
          n.nodeType === 1 && (
            n.matches?.(config.selectors.adContainer) ||
            n.querySelector?.(config.selectors.adContainer)
          )
        )
      );
      if (relevant) debouncedInject();
    });
    observer.observe(document.body, { childList: true, subtree: true });
	injectButtons();
  };

  let initialized = false;

  const initialize = () => {
    if (!window.location.href.includes("/compte/part/mes-annonces")) return;
    if (initialized) return;
    initialized = true;
    log("info", `LBC ReLister v${VERSION} prêt`);

    const run = () => {
      startObserver();
      // 6 tentatives échelonnées pour couvrir les chargements lents / lazy
      [0, 600, 1200, 2000, 3500, 6000].forEach((d) => setTimeout(injectButtons, d));
    };

    document.readyState === "loading"
      ? document.addEventListener("DOMContentLoaded", run, { once: true })
      : run();
  };

  // Navigation SPA
  window.addEventListener("popstate", () => { initialized = false; initialize(); });

  const _push = history.pushState.bind(history);
  history.pushState = function (...a) { _push(...a); initialized = false; setTimeout(initialize, 120); };

  const _replace = history.replaceState.bind(history);
  history.replaceState = function (...a) { _replace(...a); initialized = false; setTimeout(initialize, 120); };

  initialize();
})();
